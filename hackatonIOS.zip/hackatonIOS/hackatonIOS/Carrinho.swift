//
//  Carrinho.swift
//  hackatonIOS
//
//  Created by HC2MAC13 on 11/04/2018.
//  Copyright © 2018 HC2MAC13. All rights reserved.
//

import UIKit

class Carrinho {

    var itens: [Produtos] = []
    func adicionar( _ produto: Produtos ){
        
    }
    
}
