//
//  FacebookTableViewController.swift
//  Autolayout
//
//  Created by HC2MAC13 on 18/04/2018.
//  Copyright © 2018 HC2MAC13. All rights reserved.
//

import UIKit

class FacebookTableViewController: UITableViewController {

    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }

}
